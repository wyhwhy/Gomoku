﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Media;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Timers;

namespace MyGomoku
{
    public partial class Form1 : Form
    {
        public int[,] virtualGobangBoard = new int[15, 15];//虚拟棋盘
        public Stack backTrackStack = new Stack();//用于回溯的栈
        public Point bestPoint;
        GomokuOK gomo = new GomokuOK();
        //const int BLACK = -1, WHITE = 1;
        public int person;//玩家执棋子颜色
        int x0 = 50;
        
        const int background = 0, black = -1, white = 1,M=1;
        Point pb=new Point(7,7),pw;
        int y0 = 50;
        int inter = 30;
        Point p;
        int r = 12;
        int c = 0;//复盘计数器
        int HQ=3;//悔棋最多三次
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            SolidBrush blueSB = new SolidBrush(Color.Tan);
            SolidBrush whiteSB = new SolidBrush(Color.White);
            SolidBrush blackSB = new SolidBrush(Color.Black);
            Pen blackPen=new Pen(Color.Black);
            Pen redpen = new Pen(Color.Red);
            blackPen.Width=2;
            g.FillRectangle(blueSB,
                new Rectangle(x0, y0, 14 * inter, 14 * inter));
            for(int i=0;i<15;i++)
            {
                g.DrawLine(blackPen, x0, y0 + i * inter, x0 + 14 * inter, y0 + i * inter);
            }
            for (int i = 0; i < 15; i++)
            {
                g.DrawLine(blackPen, x0+i*inter, y0 , x0 + i* inter, y0 +14 * inter);
            }
            for(int i=0;i<15;i++)
            {
                for(int j=0;j<15;j++)
                {
                    if(gomo.myGets(new Point(i,j))==ChessState.BLACK)
                    {
                        Point p2 = LogicToView(new Point(i, j));
                        g.FillEllipse(blackSB, new Rectangle
                            (p2.X - r, p2.Y - r, 2 * r, 2 * r));          
                    }
                    if (gomo.myGets(new Point(i, j)) == ChessState.WHITE)
                    {
                        Point p2 = LogicToView(new Point(i, j));
                        g.FillEllipse(whiteSB, new Rectangle
                            (p2.X - r, p2.Y - r, 2 * r, 2 * r));
                    }
                }
            }
            if (gomo.Count != 0&&gomo.Current.X!=0) {
                p = LogicToView(gomo.Current);
                g.DrawLine(redpen, p.X-r-3,p.Y-r-3,p.X-r/2,p.Y-r-3);
                g.DrawLine(redpen, p.X + r/2, p.Y - r-3, p.X + r+3, p.Y - r-3);
                g.DrawLine(redpen, p.X - r-3, p.Y + r+3, p.X - r / 2, p.Y + r+3);
                g.DrawLine(redpen, p.X + r / 2, p.Y + r+3, p.X + r+3, p.Y + r+3);
                g.DrawLine(redpen, p.X - r-3, p.Y - r-3, p.X - r-3 , p.Y - r/2);
                g.DrawLine(redpen, p.X + r+3, p.Y - r-3, p.X + r+3, p.Y - r / 2);
                g.DrawLine(redpen, p.X - r-3, p.Y + r/2, p.X - r-3, p.Y + r+3);
                g.DrawLine(redpen, p.X + r+3, p.Y + r / 2, p.X + r+3, p.Y + r+3);
                redpen.Color = Color.Red;
            }
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HQ= 3;
            if (gomo.Count == 0) { button1.Visible = true; button2.Visible = true; }
            button3.Visible=false; button4.Visible = false;
            if (gomo.Count != 0)
            {
                if (MessageBox.Show("你要保存吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SaveFileDialog sa = new SaveFileDialog();
                    sa.Filter = "*.gomo(五子棋文件)|*.gomo";
                    if (sa.ShowDialog() == DialogResult.OK)
                    {
                        FileStream fs = new FileStream(sa.FileName,
                            FileMode.Create, FileAccess.Write);
                        BinaryFormatter bf = new BinaryFormatter();
                        bf.Serialize(fs, gomo);
                        fs.Close();
                    }
                }
            }
            button1.Visible = true; button2.Visible = true;
            gomo.New();gomo.Start = true;Invalidate();
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    virtualGobangBoard[i, j] = 0;
                }
            }
            复盘ToolStripMenuItem.Enabled = false;
            MessageBox.Show("请先选择哪方执黑", "提示");
        }

        private Point ViewToLogic(Point p)
        {
            Point p2 = new Point(0, 0);
            p2.X = (p.X - x0+r) / inter;
            p2.Y = (p.Y - y0+r) / inter;
            return p2;
        }
        private Point LogicToView(Point p)
        {
            Point p2 = new Point(0, 0);
            p2.X = p.X * inter + x0;
            p2.Y = p.Y * inter + y0;
            return p2;
        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((!button1.Visible)&& (!button2.Visible)&&gomo.Start&&e.Button==MouseButtons.Left)
            {
                if(e.X>x0 && e.X<x0+14*inter && e.Y>y0 
                    && e.Y<y0+14*inter)
                {
                    Point p2 = ViewToLogic(new Point(e.X, e.Y));
                    if (gomo.chessState[p2.X, p2.Y] != ChessState.BLANK) return;
                    
                    if (Forbiden(person, p2.X, p2.Y))
                    {
                        MessageBox.Show("本点为禁手点！", "提示");return;
                    }gomo.Current = p2;
                    gomo.Down();
                    if (gomo.CurrentChess == ChessState.BLACK) gomo.listw.Add(p2);
                    else gomo.listb.Add(p2);
                    if (gomo.CurrentChess == ChessState.WHITE) { pb = ViewToLogic(new Point(e.X, e.Y)); }
                    if (gomo.CurrentChess == ChessState.BLACK) { pw = ViewToLogic(new Point(e.X, e.Y)); }
                    Invalidate();
                    SoundPlayer player = new SoundPlayer();
                    player.Stream = Properties.Resources.test;
                    player.Play(); //启用新线程播放
                    悔棋ToolStripMenuItem.Enabled = true; 认输ToolStripMenuItem1.Enabled = true;
                    if (gomo.CurrentChess == ChessState.BLACK) virtualGobangBoard[p2.X, p2.Y] = 1;
                    else virtualGobangBoard[p2.X, p2.Y] = -1;
                    var result =gomo.Judge(); 
                    if (result == Result.BLACKWIN) {
                        gomo.Start = false;
                        悔棋ToolStripMenuItem.Enabled = false;
                        认输ToolStripMenuItem1.Enabled = false;
                        复盘ToolStripMenuItem.Enabled = true;
                        if (person == -1) MessageBox.Show("黑方（玩家）胜！", "本局结果");
                        else MessageBox.Show("黑方（电脑）胜！", "本局结果");
                    }
                    else if (result == Result.WHITEWIN) {
                        gomo.Start = false;
                        悔棋ToolStripMenuItem.Enabled = false;
                        认输ToolStripMenuItem1.Enabled = false;
                        复盘ToolStripMenuItem.Enabled = true;
                        if (person == -1) MessageBox.Show("白方（电脑）胜！", "本局结果");
                        else MessageBox.Show("白方（玩家）胜！", "本局结果");
                    }
                    else if (result == Result.CONTINUE && gomo.Count == 225)
                    {
                        悔棋ToolStripMenuItem.Enabled = false;
                        认输ToolStripMenuItem1.Enabled = false;
                        复盘ToolStripMenuItem.Enabled = true;
                        MessageBox.Show("平局！", "本局结果");
                    }
                    else
                    {
                        backTrackStack.Clear();
                        //bestPoint = new Point();
                        if (FindBestPoint(ref bestPoint))
                        {
                            gomo.Current = bestPoint;
                            gomo.Down();
                            if (gomo.CurrentChess == ChessState.BLACK) { pw = bestPoint; gomo.listw.Add(bestPoint); }
                            else { pb = bestPoint; gomo.listb.Add(bestPoint); }
                            Invalidate();
                            if (gomo.CurrentChess==ChessState.BLACK) virtualGobangBoard[gomo.Current.X, gomo.Current.Y] = 1;
                            else virtualGobangBoard[gomo.Current.X, gomo.Current.Y] = -1;
                            result = gomo.Judge();
                            if (result == Result.BLACKWIN)
                            {
                                gomo.Start = false;
                                悔棋ToolStripMenuItem.Enabled = false;
                                认输ToolStripMenuItem1.Enabled = false;
                                if (person == -1) MessageBox.Show("黑方（玩家）胜！", "本局结果");
                                else MessageBox.Show("黑方（电脑）胜！", "本局结果");
                                复盘ToolStripMenuItem.Enabled = true;
                            }
                            else if (result == Result.WHITEWIN)
                            {
                                gomo.Start = false;
                                悔棋ToolStripMenuItem.Enabled = false;
                                认输ToolStripMenuItem1.Enabled = false;
                                复盘ToolStripMenuItem.Enabled = true;
                                if (person==-1) MessageBox.Show("白方（电脑）胜！", "本局结果");
                                else MessageBox.Show("白方（玩家）胜！", "本局结果");
                            }
                            else if (result == Result.CONTINUE && gomo.Count == 225)
                            {
                                悔棋ToolStripMenuItem.Enabled = false;
                                认输ToolStripMenuItem1.Enabled = false;
                                复盘ToolStripMenuItem.Enabled = true;
                                MessageBox.Show("平局！", "本局结果");
                            }
                        }
                        else
                        {
                            gomo.Start = false;
                            悔棋ToolStripMenuItem.Enabled = false;
                            认输ToolStripMenuItem1.Enabled = false;
                            复盘ToolStripMenuItem.Enabled = true;
                            MessageBox.Show("恭喜你，你赢了！棋盘上所有点均为电脑的禁手点！","本局结果");
                        }
                    }
                }
            }
            gomo.vb = virtualGobangBoard;
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sa = new SaveFileDialog();
            sa.Filter = "*.gomo(五子棋文件)|*.gomo";
            if(sa.ShowDialog()==DialogResult.OK)
            {
                FileStream fs = new FileStream(sa.FileName, 
                    FileMode.Create,FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, gomo);
                fs.Close();
            }
        }

        private void 复盘ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (gomo.Count == 0) { MessageBox.Show("棋局未开始！", "提示"); return; }
            c = 0; 悔棋ToolStripMenuItem.Enabled = false;
            认输ToolStripMenuItem1.Enabled = false;
            复盘ToolStripMenuItem.Enabled = false;
            for (int i = 0; i < 15; i++)
            {
                for (int j = 0; j < 15; j++)
                {
                    gomo.chessState[i, j] = ChessState.BLANK;
                }
            }
            //gomo.Current = gomo.listb[0];
            gomo.Current = new Point(0, 0);
            Invalidate();  button3.Visible = true; button4.Visible = true;
            timer1.Enabled = true;
            
        }

        private void 悔棋ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (gomo.chessState[pb.X, pb.Y] == ChessState.BLANK
                || gomo.chessState[pw.X, pw.Y] == ChessState.BLANK) { MessageBox.Show("你已无棋可悔！", "提示"); return; }
            if (gomo.Count == 0) { MessageBox.Show("棋局未开始！", "提示"); return; }
            
            if (gomo.chessState[pb.X, pb.Y] == ChessState.BLANK
                ||gomo.chessState[pw.X, pw.Y] == ChessState.BLANK) { MessageBox.Show("你已无棋可悔！", "提示"); return; }
            if (HQ==0) { MessageBox.Show("你已用完悔棋机会！", "提示"); 悔棋ToolStripMenuItem.Enabled = false; return; }
                gomo.chessState[pw.X, pw.Y] = ChessState.BLANK;
                gomo.listw.Remove(pw); gomo.listb.Remove(pb);
                gomo.chessState[pb.X, pb.Y] = ChessState.BLANK;
            gomo.Count -= 2;
            if (person == -1 && gomo.listw.Count() > 0) gomo.Current = gomo.listw[gomo.listw.Count() - 1];
            else if (person == 1 && gomo.listb.Count() > 0) gomo.Current = gomo.listb[gomo.listb.Count() - 1];
            Invalidate(); HQ--;
            if (HQ == 2) MessageBox.Show("你还有2次悔棋机会！", "提示");
            else if (HQ == 1) MessageBox.Show("你还有1次悔棋机会！", "提示");
            else if (HQ == 0) MessageBox.Show("你已没有悔棋机会！", "提示");
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "*.gomo(五子棋文件)|*.gomo";
            if(op.ShowDialog()==DialogResult.OK)
            {
                FileStream fs = new FileStream(op.FileName,
                   FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                gomo=(GomokuOK)bf.Deserialize(fs);
                virtualGobangBoard = gomo.vb;
                Invalidate();
                if (gomo.CurrentChess == ChessState.BLACK) MessageBox.Show("您执黑", "提示");
                else MessageBox.Show("您执白", "提示");
                if (gomo.Count == 0)
                {
                    悔棋ToolStripMenuItem.Enabled = false;
                    认输ToolStripMenuItem1.Enabled = false;
                    复盘ToolStripMenuItem.Enabled = false;
                }
                else
                {
                    悔棋ToolStripMenuItem.Enabled = true;
                    认输ToolStripMenuItem1.Enabled = true;
                    复盘ToolStripMenuItem.Enabled = false;
                }
                if (gomo.flag == true) { 
                    悔棋ToolStripMenuItem.Enabled = false;
                    认输ToolStripMenuItem1.Enabled = false;
                    复盘ToolStripMenuItem.Enabled = true;
                    MessageBox.Show("你认输了！", "提示");
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("你确定要退出吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (MessageBox.Show("你要保存吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SaveFileDialog sa = new SaveFileDialog();
                    sa.Filter = "*.gomo(五子棋文件)|*.gomo";
                    if (sa.ShowDialog() == DialogResult.OK)
                    {
                        FileStream fs = new FileStream(sa.FileName,
                            FileMode.Create, FileAccess.Write);
                        BinaryFormatter bf = new BinaryFormatter();
                        bf.Serialize(fs, gomo);
                        fs.Close();
                    }
                }
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            person = -1;button1.Visible = false; button2.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Point p2 = new Point(7, 7);
            gomo.Current = p2;
            virtualGobangBoard[7, 7] = -1;
            gomo.Down(); Invalidate(); 
            gomo.listb.Add(p2);
            person = 1;button1.Visible = false; button2.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (c == gomo.Count)  return; 
            int d = Convert.ToInt32(c / 2);
            if (c % 2 == 0)
            {
                gomo.chessState[gomo.listb[d].X, gomo.listb[d].Y] = ChessState.BLACK;
                gomo.Current = gomo.listb[d];
            }
            else
            {
                gomo.chessState[gomo.listw[d].X, gomo.listw[d].Y] = ChessState.WHITE;
                gomo.Current = gomo.listw[d];
            }
                Invalidate();
            c++;
            if (c == gomo.Count)
            {
                var result = gomo.Judge();
                if (result == Result.BLACKWIN) { gomo.Start = false; button3.Visible = false; button4.Visible = false; MessageBox.Show("黑方胜！", "提示"); }
                if (result == Result.WHITEWIN) { gomo.Start = false; button3.Visible = false; button4.Visible = false; MessageBox.Show("白方胜！", "提示"); }
                if (result == Result.CONTINUE && gomo.Count == 225) { gomo.Start = false; button3.Visible = false; button4.Visible = false; MessageBox.Show("平局！", "提示"); }
                复盘ToolStripMenuItem.Enabled = true; timer1.Interval = 2000; 
                timer1.Enabled = false;
                if (gomo.flag == true) {
                    gomo.Start = false;
                    button3.Visible = false;
                    button4.Visible = false;
                    MessageBox.Show("你认输了！", "提示");
                }
                    return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (timer1.Interval-500>0)
                timer1.Interval -= 500;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (timer1.Interval + 500 <=4000)
                timer1.Interval += 500;
        }

        private void 认输ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (gomo.Count == 0) { MessageBox.Show("棋局未开始！", "提示"); return; }
            悔棋ToolStripMenuItem.Enabled = false;
            认输ToolStripMenuItem1.Enabled = false;
            复盘ToolStripMenuItem.Enabled = true;
            /*gomo.New();
            Invalidate();*/
            MessageBox.Show("你认输了！", "提示");
            gomo.Start = false;gomo.flag = true;
        }
        private bool Forbiden(int gobangColor, int x, int y)
        {
            if (gobangColor == white)
                return false;
            else
            {
                int temp = virtualGobangBoard[x, y];
                bool blntemp;
                virtualGobangBoard[x, y] = background;
                blntemp = (GetGobangPower(black, x, y) == -1);
                virtualGobangBoard[x, y] = temp;
                return blntemp;
            }
        }
        private bool ActiveConnectGobangs(int gobangColor, int count, Point point1, Point point2)
        {//判断point1与point2之间是否有gobangColor色的活count
            int x, y, i, j, length, xPlus = 0, yPlus = 0, sum;
            int temp1, temp2;
            temp1 = Math.Min(Math.Min(Math.Min(5 - count, point1.X), point1.Y), 14 - point1.Y);
            temp2 = Math.Min(Math.Min(Math.Min(5 - count, 14 - point2.X), 14 - point2.Y), point2.Y);
            length = Math.Max(Math.Abs(point1.X - point2.X), Math.Abs(point1.Y - point2.Y)) + 1 + temp1 + temp2;
            if (point1.X != point2.X) xPlus = 1;
            if (point1.Y != point2.Y) yPlus = (point2.Y - point1.Y) / Math.Abs(point2.Y - point1.Y);
            for (i = 0; i < length - 4; i++)
            {
                x = point1.X - temp1 * xPlus + i * xPlus;
                y = point1.Y - temp1 * yPlus + i * yPlus;
                if (x + 4 * xPlus > 14 || y + 4 * yPlus > 14)
                    break;
                sum = 0;
                for (j = 0; j < 4; j++)
                {
                    if (virtualGobangBoard[x + j * xPlus, y + j * yPlus] == gobangColor)
                        sum++;
                    else if (virtualGobangBoard[x + j * xPlus, y + j * yPlus] == -gobangColor)
                    {
                        sum = 0;
                        break;
                    }
                }
                if (0 < x && 0 <= y - yPlus && y - yPlus <= 14)
                {
                    if (sum == count && virtualGobangBoard[x - xPlus, y - yPlus] == background && virtualGobangBoard[x + 4 * xPlus, y + 4 * yPlus] == background)
                        return true;
                }
            }
            return false;
        }

        private bool BreakActiveConnectGobangs(int gobangColor, int count, int x, int y, Point point1, Point point2)
        {//(x,y)处放gobangColor色棋后形成活count,且放一反色棋后破坏棋形成活count的能，注意返回时不能破坏棋盘
            if (!ActiveConnectGobangs(gobangColor, count, point1, point2)) return false;
            if (count == 5) return false;
            else if (count == 4) return true;
            else
            {
                bool blnFlag;
                virtualGobangBoard[x, y] = -gobangColor;
                blnFlag = !ActiveConnectGobangs(gobangColor, count - 1, point1, point2);
                virtualGobangBoard[x, y] = gobangColor;
                return blnFlag;
            }
        }
        private bool lenthConnectTowPoint(Point point1, Point point2)
        {
            //求point1与point2之间是否能形成长连禁手
            int x, y, i, j, length, xPlus = 0, yPlus = 0, sum;
            length = Math.Max(Math.Abs(point1.X - point2.X), Math.Abs(point1.Y - point2.Y)) + 1;
            if (point1.X != point2.X) xPlus = 1;
            if (point1.Y != point2.Y) yPlus = (point2.Y - point1.Y) / Math.Abs(point2.Y - point1.Y);
            for (i = 0; i < length - 5; i++)
            {
                x = point1.X + i * xPlus;
                y = point1.Y + i * yPlus;
                sum = 0;
                for (j = 0; j < 6; j++)
                {
                    if (virtualGobangBoard[x + j * xPlus, y + j * yPlus] == black)
                        sum++;
                    else
                    {
                        sum = 0;
                        break;
                    }
                }
                if (sum == 6) return true;
            }
            return false;
        }
        private bool lenthConnect(int x, int y)
        {
            Point left, right, top, down, leftTop, rightTop, leftDown, rightDown;
            int temp;
            int tempppppp = virtualGobangBoard[x, y];
            virtualGobangBoard[x, y] = black;
            bool blntemp;
            left = new Point(Math.Max(0, x - 5), y);
            right = new Point(Math.Min(14, x + 5), y);
            top = new Point(x, Math.Max(0, y - 5));
            down = new Point(x, Math.Min(14, y + 5));
            temp = Math.Min(x - left.X, y - top.Y);
            leftTop = new Point(x - temp, y - temp);
            temp = Math.Min(x - left.X, down.Y - y);
            leftDown = new Point(x - temp, y + temp);
            temp = Math.Min(right.X - x, y - top.Y);
            rightTop = new Point(x + temp, y - temp);
            temp = Math.Min(right.X - x, down.Y - y);
            rightDown = new Point(x + temp, y + temp);
            blntemp = (lenthConnectTowPoint(left, right) || lenthConnectTowPoint(top, down) || lenthConnectTowPoint(leftTop, rightDown) || lenthConnectTowPoint(leftDown, rightTop));
            virtualGobangBoard[x, y] = tempppppp;
            return blntemp;

        }
        private int ConnectGobangsCount(int gobangColor, Point point1, Point point2)
        {
            int x, y, i, j, length, xPlus = 0, yPlus = 0, sum, maxSum = 0;
            length = Math.Max(Math.Abs(point1.X - point2.X), Math.Abs(point1.Y - point2.Y)) + 1;
            if (point1.X != point2.X) xPlus = 1;
            if (point1.Y != point2.Y) yPlus = (point2.Y - point1.Y) / Math.Abs(point2.Y - point1.Y);
            for (i = 0; i < length - 4; i++)
            {
                x = point1.X + i * xPlus;
                y = point1.Y + i * yPlus;
                sum = 0;
                for (j = 0; j < 5; j++)
                {
                    if (virtualGobangBoard[x + j * xPlus, y + j * yPlus] == gobangColor)
                        sum++;
                    else if (virtualGobangBoard[x + j * xPlus, y + j * yPlus] == -gobangColor)
                    {
                        sum = 0;
                        break;
                    }
                }
                if (maxSum < sum)
                    maxSum = sum;
            }
            return maxSum;
        }
        private int GetGobangPower(int gobangColor, int x, int y)
        {//求(x,y)点对于gobangColor色棋的权值
            int totalPower;
            GobangPointAttributinton gobPtAttri = new GobangPointAttributinton();
            Point left, right, top, down, leftTop, rightTop, leftDown, rightDown;
            int temp, connectCount;
            left = new Point(Math.Max(0, x - 4), y);
            right = new Point(Math.Min(14, x + 4), y);
            top = new Point(x, Math.Max(0, y - 4));
            down = new Point(x, Math.Min(14, y + 4));
            temp = Math.Min(x - left.X, y - top.Y);
            leftTop = new Point(x - temp, y - temp);
            temp = Math.Min(x - left.X, down.Y - y);
            leftDown = new Point(x - temp, y + temp);
            temp = Math.Min(right.X - x, y - top.Y);
            rightTop = new Point(x + temp, y - temp);
            temp = Math.Min(right.X - x, down.Y - y);
            rightDown = new Point(x + temp, y + temp);
            if (gobangColor == black)
            {
                if (virtualGobangBoard[x, y] != background)
                    return -2;
                else
                {
                    ///
                    ///处理黑棋连子情况
                    ///
                    virtualGobangBoard[x, y] = black;
                    //左右方向
                    connectCount = ConnectGobangsCount(black, left, right);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (ActiveConnectGobangs(black, connectCount, left, right))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //上下方向
                    connectCount = ConnectGobangsCount(black, top, down);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (ActiveConnectGobangs(black, connectCount, top, down))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //左上_右下方向
                    connectCount = ConnectGobangsCount(black, leftTop, rightDown);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (ActiveConnectGobangs(black, connectCount, leftTop, rightDown))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //左下_右上方向
                    connectCount = ConnectGobangsCount(black, leftDown, rightTop);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (ActiveConnectGobangs(black, connectCount, leftDown, rightTop))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    virtualGobangBoard[x, y] = background;

                    ///
                    ///处理白棋连子情况
                    ///

                    virtualGobangBoard[x, y] = white;
                    //左右方向
                    connectCount = ConnectGobangsCount(white, left, right);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(white, connectCount, x, y, left, right))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //上下方向
                    connectCount = ConnectGobangsCount(white, top, down);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(white, connectCount, x, y, top, down))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //左上_右下方向
                    connectCount = ConnectGobangsCount(white, leftTop, rightDown);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(white, connectCount, x, y, leftTop, rightDown))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //左下_右上方向
                    connectCount = ConnectGobangsCount(white, leftDown, rightTop);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(white, connectCount, x, y, leftDown, rightTop))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    if (ActiveConnectGobangs(white, 3, left, right) && ConnectGobangsCount(white, left, right) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(white, 3, top, down) && ConnectGobangsCount(white, top, down) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(white, 3, leftTop, rightDown) && ConnectGobangsCount(white, leftTop, rightDown) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(white, 3, leftDown, rightTop) && ConnectGobangsCount(white, leftDown, rightTop) <= 3) gobPtAttri.tempActive3++;
                    virtualGobangBoard[x, y] = background;
                    //
                    //开始求权值
                    //
                    if (gobPtAttri.blackActive[3] > 1 || gobPtAttri.blackActive[4] > 1 || lenthConnect(x, y))
                        return -1;//禁手
                    else if (gobPtAttri.blackConnect[5] > 0)
                        return 150000;
                    else if (gobPtAttri.whiteConnect[5] > 0)
                        return 140000;
                    else if (gobPtAttri.blackActive[4] > 0 || gobPtAttri.blackConnect[4] > 1)
                        return 130000;
                    else if (gobPtAttri.blackConnect[4] == 1 && gobPtAttri.blackActive[3] == 1)
                        return 120000;
                    else if (gobPtAttri.blackConnect[4] == 1 && gobPtAttri.blackConnect[3] > 0)
                        return 110000;
                    else if (gobPtAttri.whiteActive[4] > 0 || gobPtAttri.whiteConnect[4] > 1)
                        return 100000;
                    else if (gobPtAttri.whiteConnect[4] == 1 && gobPtAttri.tempActive3 == 1)
                        return 90000;
                    else if (gobPtAttri.whiteActive[3] > 1)
                        return 80000;
                    else if (gobPtAttri.whiteConnect[4] == 1 && gobPtAttri.whiteConnect[3] > 0)
                        return 70000;
                    else
                    {
                        totalPower = (gobPtAttri.blackConnect[4] + gobPtAttri.blackActive[3]) * 6250 + (gobPtAttri.blackConnect[3] + gobPtAttri.blackActive[2] + gobPtAttri.whiteConnect[4] + gobPtAttri.whiteActive[3]) * 1250
                        + (gobPtAttri.blackConnect[2] + gobPtAttri.whiteConnect[3] + gobPtAttri.whiteActive[2]) * 250 + gobPtAttri.blackActive[1] * 50 + (gobPtAttri.blackConnect[1] + gobPtAttri.whiteConnect[2] + gobPtAttri.whiteActive[1]) * 10 + gobPtAttri.whiteConnect[1] * 2;
                        return totalPower;
                    }

                }
            }
            else //gobangColor==white
            {
                if (virtualGobangBoard[x, y] != background)
                    return -2;
                else
                {
                    ///
                    ///处理黑棋连子情况
                    ///
                    virtualGobangBoard[x, y] = black;





                    //左右方向
                    connectCount = ConnectGobangsCount(black, left, right);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(black, connectCount, x, y, left, right))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //上下方向
                    connectCount = ConnectGobangsCount(black, top, down);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(black, connectCount, x, y, top, down))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //左上_右下方向
                    connectCount = ConnectGobangsCount(black, leftTop, rightDown);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(black, connectCount, x, y, leftTop, rightDown))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    //左下_右上方向
                    connectCount = ConnectGobangsCount(black, leftDown, rightTop);
                    gobPtAttri.blackConnect[connectCount]++;
                    if (BreakActiveConnectGobangs(black, connectCount, x, y, leftDown, rightTop))
                    {
                        gobPtAttri.blackConnect[connectCount]--;
                        gobPtAttri.blackActive[connectCount]++;
                    }
                    if (ActiveConnectGobangs(black, 3, left, right) && ConnectGobangsCount(black, left, right) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(black, 3, top, down) && ConnectGobangsCount(black, top, down) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(black, 3, leftTop, rightDown) && ConnectGobangsCount(black, leftTop, rightDown) <= 3) gobPtAttri.tempActive3++;
                    if (ActiveConnectGobangs(black, 3, leftDown, rightTop) && ConnectGobangsCount(black, leftDown, rightTop) <= 3) gobPtAttri.tempActive3++;
                    virtualGobangBoard[x, y] = background;

                    ///
                    ///处理白棋连子情况
                    ///
                    if (x == 6 && y == 9)
                        x = 6;


                    virtualGobangBoard[x, y] = white;
                    //左右方向
                    connectCount = ConnectGobangsCount(white, left, right);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (ActiveConnectGobangs(white, connectCount, left, right))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //上下方向
                    connectCount = ConnectGobangsCount(white, top, down);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (ActiveConnectGobangs(white, connectCount, top, down))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //左上_右下方向
                    connectCount = ConnectGobangsCount(white, leftTop, rightDown);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (ActiveConnectGobangs(white, connectCount, leftTop, rightDown))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    //左下_右上方向
                    connectCount = ConnectGobangsCount(white, leftDown, rightTop);
                    gobPtAttri.whiteConnect[connectCount]++;
                    if (ActiveConnectGobangs(white, connectCount, leftDown, rightTop))
                    {
                        gobPtAttri.whiteConnect[connectCount]--;
                        gobPtAttri.whiteActive[connectCount]++;
                    }
                    virtualGobangBoard[x, y] = background;
                    //
                    //开始求权值
                    //
                    bool blnBlackForbiden = (gobPtAttri.tempActive3 > 1 || gobPtAttri.blackActive[4] > 1 || lenthConnect(x, y));
                    if (gobPtAttri.whiteConnect[5] > 0)
                        return 150000;
                    else if (gobPtAttri.blackConnect[5] > 0 && !blnBlackForbiden)
                        return 140000;
                    else if (gobPtAttri.whiteActive[4] > 0 || gobPtAttri.whiteConnect[4] > 1)
                        return 130000;
                    else if (gobPtAttri.whiteConnect[4] == 1 && gobPtAttri.whiteActive[3] > 0)
                        return 120000;
                    else if (gobPtAttri.blackActive[4] == 1 && !blnBlackForbiden || gobPtAttri.blackConnect[4] > 1 && !blnBlackForbiden)
                        return 110000;
                    else if (gobPtAttri.whiteConnect[4] == 1 && gobPtAttri.whiteConnect[3] > 0)
                        return 100000;
                    else if (gobPtAttri.blackConnect[4] > 0 && gobPtAttri.tempActive3 == 1 && !blnBlackForbiden)
                        return 90000;
                    else if (gobPtAttri.whiteActive[3] > 1)
                        return 80000;
                    else if (gobPtAttri.blackConnect[4] > 0 && gobPtAttri.blackConnect[3] > 0 && !blnBlackForbiden)
                        return 70000;
                    else
                    {
                        totalPower = (gobPtAttri.whiteConnect[4] + gobPtAttri.whiteActive[3]) * 6250 + (gobPtAttri.whiteConnect[3] + gobPtAttri.whiteActive[2] + gobPtAttri.blackConnect[4] + gobPtAttri.blackActive[3]) * 1250
                        + (gobPtAttri.whiteConnect[2] + gobPtAttri.blackConnect[3] + gobPtAttri.blackActive[2]) * 250 + gobPtAttri.whiteActive[1] * 50 + (gobPtAttri.whiteConnect[1] + gobPtAttri.blackConnect[2] + gobPtAttri.blackActive[1]) * 10 + gobPtAttri.blackConnect[1] * 2;
                        return totalPower;
                    }
                }
            }
        }
        private bool FindBestFivePointsAndFormAStackElement(int gobangColor, ref StackElement tempStackElement)
        {//寻找最佳的五个点，并形成栈元素，若一个也找不到返回false
            int[,] gobangPower = new int[15, 15];
            bool blnHaveFound;
            int x, y, i, max;
            tempStackElement.pointsCount = 0;
            for (x = 0; x < 15; x++)
                for (y = 0; y < 15; y++)
                    gobangPower[x, y] = GetGobangPower(gobangColor, x, y);
            for (i = 0; i < 5; i++)
            {//求第i个最佳点
                max = 0;
                for (x = 0; x < 15; x++)
                    for (y = 0; y < 15; y++)
                        if (max < gobangPower[x, y])
                            max = gobangPower[x, y];
                for (x = 0; x < 15; x++)
                {
                    blnHaveFound = false;
                    for (y = 0; y < 15; y++)
                        if (max == gobangPower[x, y])
                        {
                            tempStackElement.bestFivePoints[i] = new Point(x, y);
                            tempStackElement.pointsCount++;
                            gobangPower[x, y] = -1;
                            blnHaveFound = true;
                            break;
                        }
                    if (blnHaveFound) break;
                }

            }
            if (tempStackElement.pointsCount == 0)
                return false;
            else
            {
                tempStackElement.gobangColor = gobangColor;
                tempStackElement.pointNumber = 0;
                return true;
            }
        }
        private bool FindBestPoint(ref Point bestPoint)
        {
            Conclution totalConclution = Conclution.lose;
            int i, bestStepNumber = 0;
            StackElement tempStackElement = new StackElement();
            if (!FindBestFivePointsAndFormAStackElement(0-person, ref tempStackElement))
                return false;
            backTrackStack.Push(tempStackElement);
            while (backTrackStack.Count > 0)//栈非空
            {
                tempStackElement = (StackElement)backTrackStack.Pop();
                if (tempStackElement.pointNumber < tempStackElement.pointsCount)
                {
                    //在虚拟棋盘上下一棋
                    virtualGobangBoard[tempStackElement.bestFivePoints[tempStackElement.pointNumber].X, tempStackElement.bestFivePoints[tempStackElement.pointNumber].Y] = tempStackElement.gobangColor;
                    if (Win(tempStackElement.gobangColor, tempStackElement.bestFivePoints[tempStackElement.pointNumber]))
                    {//赢棋，不在继续探测
                        tempStackElement.theConclution[tempStackElement.pointNumber] = Conclution.win;
                        tempStackElement.stepNumber[tempStackElement.pointNumber] = backTrackStack.Count + 1;
                        //在虚拟棋盘上退一棋
                        virtualGobangBoard[tempStackElement.bestFivePoints[tempStackElement.pointNumber].X, tempStackElement.bestFivePoints[tempStackElement.pointNumber].Y] = background;
                        tempStackElement.pointNumber++;
                        backTrackStack.Push(tempStackElement);
                    }
                    else if (backTrackStack.Count == M - 1)
                    {//将此元素压入栈后栈满，不在继续探测
                        tempStackElement.theConclution[tempStackElement.pointNumber] = Conclution.equal;
                        tempStackElement.stepNumber[tempStackElement.pointNumber] = M;
                        //在虚拟棋盘上退一棋
                        virtualGobangBoard[tempStackElement.bestFivePoints[tempStackElement.pointNumber].X, tempStackElement.bestFivePoints[tempStackElement.pointNumber].Y] = background;
                        tempStackElement.pointNumber++;
                        backTrackStack.Push(tempStackElement);
                    }
                    else
                    {//另一方继续下棋向下探测
                        tempStackElement.pointNumber++;
                        backTrackStack.Push(tempStackElement);
                        FindBestFivePointsAndFormAStackElement(-tempStackElement.gobangColor, ref tempStackElement);
                        backTrackStack.Push(tempStackElement);
                    }
                }//end if
                else//栈顶元素无点或点均已试过
                {
                    if (tempStackElement.pointsCount == 0)//栈顶元素无点，且弹出后栈必非空
                    {
                        tempStackElement = (StackElement)backTrackStack.Pop();
                        tempStackElement.theConclution[tempStackElement.pointNumber - 1] = Conclution.win;
                        tempStackElement.stepNumber[tempStackElement.pointNumber - 1] = backTrackStack.Count + 1;
                        //在虚拟棋盘上退一棋
                        virtualGobangBoard[tempStackElement.bestFivePoints[tempStackElement.pointNumber - 1].X, tempStackElement.bestFivePoints[tempStackElement.pointNumber - 1].Y] = background;
                        backTrackStack.Push(tempStackElement);
                    }
                    else//栈顶元素中点均已试过
                    {
                        //寻找栈顶元素中点的最好结局
                        totalConclution = tempStackElement.theConclution[0];
                        for (i = 0; i < tempStackElement.pointsCount; i++)
                            if (totalConclution < tempStackElement.theConclution[i])
                                totalConclution = tempStackElement.theConclution[i];
                        //寻找最佳步数
                        if (totalConclution == Conclution.win)
                        {
                            bestStepNumber = M + 2;
                            for (i = 0; i < tempStackElement.pointsCount; i++)
                                if (totalConclution == tempStackElement.theConclution[i] && bestStepNumber > tempStackElement.stepNumber[i])
                                    bestStepNumber = tempStackElement.stepNumber[i];
                        }
                        else//totalConclution==Conclution.equal或lose
                        {
                            bestStepNumber = 0;
                            for (i = 0; i < tempStackElement.pointsCount; i++)
                                if (totalConclution == tempStackElement.theConclution[i] && bestStepNumber < tempStackElement.stepNumber[i])
                                    bestStepNumber = tempStackElement.stepNumber[i];
                        }
                        if (backTrackStack.Count > 0)//栈非空
                        {
                            tempStackElement = (StackElement)backTrackStack.Pop();
                            tempStackElement.theConclution[tempStackElement.pointNumber - 1] = (Conclution)(0 - totalConclution);
                            tempStackElement.stepNumber[tempStackElement.pointNumber - 1] = bestStepNumber;
                            //在虚拟棋盘上退一棋
                            virtualGobangBoard[tempStackElement.bestFivePoints[tempStackElement.pointNumber - 1].X, tempStackElement.bestFivePoints[tempStackElement.pointNumber - 1].Y] = background;
                            backTrackStack.Push(tempStackElement);
                        }
                    }//end else
                }//end else
            }//end while
            //栈已空
            for (i = 0; i < tempStackElement.pointsCount; i++)
                if (totalConclution == tempStackElement.theConclution[i] && bestStepNumber == tempStackElement.stepNumber[i])
                    break;
            bestPoint = tempStackElement.bestFivePoints[i];
            return true;
        }
        private bool Win(int gobangColor, int x, int y)//在(x,y)上放一gobangColor色的棋后，判断gobangColor色棋是否赢
        {
            bool blnWin;
            virtualGobangBoard[x, y] = background;
            if (GetGobangPower(gobangColor, x, y) >= 150000)
                blnWin = true;
            else
                blnWin = false;
            virtualGobangBoard[x, y] = gobangColor;
            return blnWin;
        }
        private bool Win(int gobangColor, Point point)
        {
            return Win(gobangColor, point.X, point.Y);
        }
    }
    public class GobangPointAttributinton//棋子点属性，包括连子数及权值
    {
        public int[] blackConnect = new int[6];
        public int[] blackActive = new int[6];
        public int[] whiteConnect = new int[6];
        public int[] whiteActive = new int[6];
        public int tempActive3;
    }
    public class StackElement//回溯栈元素
    {
        public int gobangColor;
        public Point[] bestFivePoints = new Point[5];
        public int pointsCount;
        public int pointNumber;
        public Conclution[] theConclution = new Conclution[5];
        public int[] stepNumber = new int[5];
    }
}
