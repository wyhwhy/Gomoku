﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyGomoku
{
    public enum Conclution : int//结局
    {
        lose = -1,
        equal=0,
        win=1
    }
    public enum ChessState
    {
        BLANK,
        BLACK,
        WHITE
    }
    public enum Result
    {
        BLACKWIN,
        WHITEWIN,
        CONTINUE
    }
    
    [Serializable]
    public abstract class Gomoku
    {
        public ChessState[,] chessState = new
            ChessState[15, 15];
        public int[,] vb = new int[15, 15];
        public bool Start { get; set; }
        public List<Point> listb = new List<Point>();
        public List<Point> listw = new List<Point>();
        public abstract Result Judge();
        public bool flag { get; set; }
        public int Count { get; set; }
        public Point Current{get;set;}
        public ChessState CurrentChess{get;set;}
        public abstract void Down();
        public abstract void New();
    }
    
    [Serializable]
    public class GomokuOK : Gomoku
    {
        public int l = 0, r = 0, u = 0, d = 0, ne = 0, nw = 0, se = 0, sw = 0;
        public GomokuOK()
        {
            New();
        }
        public override void New()
        {
            listb.Clear();
            listw.Clear();
            for(int i=0;i<15;i++)
            {
                for(int j=0;j<15;j++)
                {
                    chessState[i, j] = ChessState.BLANK;
                }
            }
            Count = 0;
            flag = false;
            Start = false;
            CurrentChess=ChessState.BLACK;
        }
        public ChessState myGets(Point p)
        {
            return chessState[p.X, p.Y];
        }
        public override void Down()
        {
            if(chessState[Current.X,Current.Y]==ChessState.BLANK)
            {
                if(CurrentChess==ChessState.BLACK)
                {
                    chessState[Current.X, Current.Y] = ChessState.BLACK;
                    CurrentChess = ChessState.WHITE;
                }
                else if (CurrentChess == ChessState.WHITE)
                {
                    chessState[Current.X, Current.Y] = ChessState.WHITE;
                    CurrentChess = ChessState.BLACK;
                }
                Count++;
            }
        }
        public override Result Judge()
        {
            l = r = u = d = ne = nw = se = sw = 0;
            for (int i = Current.X-1; i >= 0; i--)
            {
                if (chessState[i, Current.Y] == chessState[Current.X, Current.Y]) l++;
                else break;
            }
            for (int i = Current.X+1; i < 15; i++)
            {
                if (chessState[i, Current.Y] == chessState[Current.X, Current.Y]) r++;
                else break;
            }
            for (int i = Current.Y-1; i >= 0; i--)
            {
                if (chessState[Current.X, i] == chessState[Current.X, Current.Y]) u++;
                else break;
            }
            for (int i = Current.Y+1; i < 15; i++)
            {
                if (chessState[Current.X, i] == chessState[Current.X, Current.Y]) d++;
                else break;
            }
            for (int i = Current.X+1, j = Current.Y+1;
                i < 15 && i >= 0 && j < 15 && j >= 0; i++, j++)
            {
                if (chessState[i, j] == chessState[Current.X, Current.Y]) se++;
                else break;
            }
            for (int i = Current.X+1, j = Current.Y-1;
                i < 15 && i >= 0 && j < 15 && j >= 0; i++, j--)
            {
                if (chessState[i, j] == chessState[Current.X, Current.Y]) ne++;
                else break;
            }
            for (int i = Current.X-1, j = Current.Y+1;
                i < 15 && i >= 0 && j < 15 && j >= 0; i--, j++)
            {
                if (chessState[i, j] == chessState[Current.X, Current.Y]) sw++;
                else break;
            }
            for (int i = Current.X-1, j = Current.Y-1;
                i < 15 && i >= 0 && j < 15 && j >= 0; i--, j--)
            {
                if (chessState[i, j] == chessState[Current.X, Current.Y]) nw++;
                else break;
            }
            if (l + r == 4 || u + d == 4 || ne + sw == 4 || nw + se == 4)
            {
                if (CurrentChess == ChessState.BLACK) return Result.WHITEWIN;
                else return Result.BLACKWIN;
            }
            return Result.CONTINUE;
        }
    }
}
